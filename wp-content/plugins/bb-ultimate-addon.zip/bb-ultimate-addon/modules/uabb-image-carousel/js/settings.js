(function($){

	FLBuilder.registerModuleHelper('photo-gallery', {

	});

})(jQuery);